package math;

import io.FileIO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayOperationsTest {
    private ArrayOperations arrayOperations;
    private FileIO fileio;
    private MyMath myMath;

    @BeforeEach
    void setUp() {
        arrayOperations = new ArrayOperations();
        fileio = new FileIO();
        myMath = new MyMath();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void findPrimesInFile() {
        String filePath = "/home/samdani1412/Desktop/Semester6/Software Testing/unittesting/src/test/resources/grades_valid.txt";

        int[] expected = {3, 2, 3, 3};
        int[] result = arrayOperations.findPrimesInFile(fileio, filePath, myMath);

        assertArrayEquals(expected, result);
    }
}
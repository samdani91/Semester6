package org.example.webapp;

import org.example.message.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class MessageController {

    @Autowired
    private MessageService messageService;

    @GetMapping("/")
    public String showForm() {
        return "index";
    }

    @PostMapping("/reverse")
    public String reverseMessage(@RequestParam("message") String message, Model model) {
        String reversed = messageService.reverse(message);
        model.addAttribute("original", message);
        model.addAttribute("reversed", reversed);
        return "index";
    }
}

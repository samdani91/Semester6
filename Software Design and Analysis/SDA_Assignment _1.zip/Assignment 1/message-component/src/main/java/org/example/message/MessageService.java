package org.example.message;


import org.springframework.stereotype.Service;

@Service
public class MessageService {
    public String reverse(String input) {
        System.out.println("Message from frontend: " + input);
        return new StringBuilder(input).reverse().toString();
    }
}
